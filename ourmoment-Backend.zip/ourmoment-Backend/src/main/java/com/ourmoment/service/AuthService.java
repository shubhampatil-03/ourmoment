package com.ourmoment.service;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.ourmoment.dto.RegisterRequest;
import com.ourmoment.entity.User;
import com.ourmoment.repository.UserRepository;
import com.ourmoment.dto.LoginRequest;
import com.ourmoment.dto.LoginResponse;
import com.ourmoment.service.*;
import java.util.Map;
@Service
public class AuthService {

	private final UserRepository userRepository;
	private final PasswordEncoder passwordEncoder;
	private final JwtService jwtService;
	public AuthService(UserRepository userRepository,
			PasswordEncoder passwordEncoder,
			JwtService jwtService) {
		this.userRepository = userRepository;
		this.passwordEncoder= passwordEncoder;
		 this.jwtService = jwtService;
		
	}
	
	public User register(RegisterRequest request) {
		if(userRepository.existsByEmail(request.getEmail())) {
			throw new RuntimeException("Email already exista");
		}
		
		User user = new User();
		
		user.setName(request.getName());
		user.setEmail(request.getEmail());
		
		user.setPassword(passwordEncoder.encode(request.getPassword()));
		return userRepository.save(user);
	
	
	}
	
	public LoginResponse login(LoginRequest request) {

	    User user = userRepository.findByEmail(request.getEmail())
	            .orElseThrow(() ->
	                    new RuntimeException("Invalid email or password"));

	    if (!passwordEncoder.matches(
	            request.getPassword(), user.getPassword())) {
	        throw new RuntimeException("Invalid email or password");
	    }

	    String token = jwtService.generateToken(user.getEmail());

	    return new LoginResponse(
	            token,
	            user.getId(),
	            user.getName(),
	            user.getEmail()
	    );
	}
	
}
